"""Pydantic models for request/response validation."""
