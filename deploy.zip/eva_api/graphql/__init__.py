"""
GraphQL API module.

Provides GraphQL schema, resolvers, and subscriptions.
"""
